// v14 detection check.
//
// Two halves, because tightening the detector can only be trusted if both hold:
//   1. every real sample still lands on exactly its own version, and v15 is not
//      claimed;
//   2. nothing else is claimed. `loadstring`, `load(` and a generic
//      `function(...)` wrapper are not evidence of anything - Hercules, MoonSec
//      and ordinary scripts have all three, and scoring them claimed 9 Hercules
//      samples as v14.6.
//
// Run: node deobfuscators/luraph_v14_detect_check.cjs
const fs = require('fs');
const path = require('path');
const v14 = require('./luraph_v14_deob');
const ROOT = path.join(__dirname, '..');

const D = [
    ['v14.6', v14.detectLuraphV146, 'isLuraphV146'],
    ['v14.7', v14.detectLuraphV147, 'isLuraphV147'],
    ['v14.8', v14.detectLuraphV148, 'isLuraphV148'],
    ['v14.9', v14.detectLuraphV149, 'isLuraphV149'],
];
const claimed = (text) => D.filter(([, fn, key]) => fn(text)[key]).map(([n]) => n);

// half 1: the samples we have, each on its own version
const DIR = path.join(ROOT, 'Samples', 'Luraph');
const WANT = {
    'luraph-v14.6.lua': 'v14.6',
    'luraph-v14.7.lua': 'v14.7',
    'luraph-v14.7 (1).lua': 'v14.7',
    'luraph-v14.7 (2).lua': 'v14.7',
    'luraph-v14.7 (3).lua': 'v14.7',
    'luraph-v14.7 (4).lua': 'v14.7',
    'luraph-v14.8.lua': 'v14.8',
    'luraph-v14.9.lua': 'v14.9',
    'luraph-v15.lua': null,
    'luraph-v15 (1).lua': null,
};

let bad = 0;
console.log('--- real samples ---');
for (const [name, want] of Object.entries(WANT)) {
    const p = path.join(DIR, name);
    if (!fs.existsSync(p)) { console.log(`skip  ${name} (not present)`); continue; }
    const hits = claimed(fs.readFileSync(p, 'utf8'));
    const got = hits.length === 1 ? hits[0] : (hits.length ? hits.join(',') : null);
    const ok = got === want;
    if (!ok) bad += 1;
    console.log(`${ok ? 'ok  ' : 'FAIL'} ${name.padEnd(22)} want=${String(want).padEnd(6)} got=${got}`);
}

// half 2: every other Luau file in the repo must go unclaimed
console.log('\n--- other files (must not be claimed) ---');
// genuinely v14 but bannerless: the recovered stages we extracted ourselves.
// They are what the no-banner path exists to catch, so claiming them is right.
const KNOWN_BANNERLESS = new Set([
    path.join('tools', 'work', 'stage147.lua'),
    path.join('tools', 'work', 'stage147_inst.lua'),
]);
const files = [];
(function walk(d) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const p = path.join(d, e.name);
        if (e.isDirectory()) {
            if (e.name === 'bin' || e.name === '__pycache__') continue;
            walk(p);
        } else if (/\.luau?$/.test(e.name)) files.push(p);
    }
})(ROOT);

let scanned = 0;
for (const f of files) {
    const src = fs.readFileSync(f, 'utf8');
    // our own outputs carry the recovered stage, which keeps the banner: they
    // are outputs, not inputs, and must never be fed back in
    if (f.includes(`${path.sep}output${path.sep}`)) continue;
    const rel = path.relative(ROOT, f);
    if (KNOWN_BANNERLESS.has(rel)) {
        const hits = claimed(src);
        const ok = hits.length > 0;
        if (!ok) bad += 1;
        console.log(`${ok ? 'ok  ' : 'FAIL'} bannerless stage still claimed: ${rel}`);
        continue;
    }
    scanned += 1;
    const hits = claimed(src);
    if (hits.length && !/Luraph\s+Obfuscator\s+v14/i.test(src.slice(0, 4000))) {
        bad += 1;
        console.log(`FAIL CLAIMED ${hits.join(',')} : ${rel}`);
    }
}
console.log(`${scanned} file(s) scanned`);
console.log(`\n${bad} problem(s)`);
process.exit(bad ? 1 : 0);
