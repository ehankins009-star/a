// Luraph v14.6 / v14.7 as /deob engines.
//
// v14 is not a bytecode-lifting engine like the v15 devirtualizer: its payload
// only exists at runtime, so the only way to see it is to run it. The engine
// (deobfuscators/luraph_v15/deobf) runs the script in a real Luau VM against a
// fake Roblox environment and renders what it did back as Luau.
//
// Two things make v14 need more than a plain run, both handled inside the
// engine's v14 plugin (obfuscators/luraph_v14/__init__.py):
//
//   * the decrypted stage (the VM runtime) has to have its loop heads
//     instrumented before it runs, or the run is a pure-VM endless loop the
//     tracer cannot see. The stage comes from host-decoded zstd blobs, from
//     the file itself (v14.7 base and v14.8 ship the VM as the whole file), or
//     from a first capture pass (the LZ loaders loadstring it).
//   * the interpreter must be driven past its own spin watchdog, which is
//     what turns a silent hang into a finished run with a trace.
//
// So this wrapper is thin: it runs deob.py and returns the trace file
// (<name>.deobf.luau) - the readable answer, as opposed to <name>.luau, which
// is the recovered stage plus its dispatch tables.
//
// The instrumenter has to be Python: the runtime is Luau and has no parser,
// and matching the dispatch loops with a pattern injects out-of-scope names
// and stops the stage running.
'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const { runProcess, probeCommand } = require('./proc');

const ENGINE_DIR = path.join(__dirname, 'luraph_v15', 'deobf');
const ENGINE_PY = path.join(ENGINE_DIR, 'deob.py');
const BIN_DIR = path.join(ENGINE_DIR, 'bin');
const LUAU_EXE = path.join(BIN_DIR, process.platform === 'win32' ? 'luau.exe' : 'luau');
const LUAU_AST_EXE = path.join(BIN_DIR, process.platform === 'win32' ? 'luau-ast.exe' : 'luau-ast');
const DEFAULT_TIMEOUT = 300;

const VERSION_BANNER = /Luraph\s+Obfuscator\s+v([\d.]+)/i;
// v14-specific shapes only. `loadstring`, `load(` and a generic
// `function(...)` wrapper are deliberately NOT evidence: Hercules, MoonSec and
// ordinary scripts all have those, and scoring them claimed 9 Hercules samples
// as v14.6 - small files with a polyfill header and one `loadstring` hit the
// threshold on nothing.
const INLINE_VM = /^\s*(?:--[^\n]*\n)*\s*return\s*\(\s*\{\s*[A-Za-z_]\w*\s*=\s*function/;
// the stage anywhere in the file: a closure table returned from the loader
const CLOSURE_TABLE = /return\s*\(\s*\{\s*[A-Za-z_]\w*\s*=\s*function/;
// the step wrapper every v14 interpreter sits behind (see LURAPH14.md)
const STEP_WRAPPER = new RegExp(
    'repeat\\s+[A-Za-z_]\\w*\\s*,\\s*[A-Za-z_]\\w*\\s*,\\s*[A-Za-z_]\\w*\\s*,\\s*[A-Za-z_]\\w*'
    + '\\s*=\\s*[A-Za-z_]\\w*\\s*:\\s*[A-Za-z_]\\w*\\s*\\(');
// the loader's own marker, e.g. the `LPH` prefixed keys it seeds its decoder
// with; read off real v14 stages, not guessed
const LPH_MARK = /LPH[_A-Z0-9*]/;

const PY_CANDIDATES = ['python3', 'python', 'py', '/usr/bin/python3', '/usr/local/bin/python3'];
const IS_PYTHON = /python/i;

let cachedPy;
function pythonCommand() {
    if (cachedPy !== undefined) return cachedPy;
    cachedPy = null;
    for (const candidate of PY_CANDIDATES) {
        try {
            const probe = spawnSync(candidate, ['-c', 'print(1)'], { timeout: 8000, windowsHide: true });
            if (probe.status === 0) return (cachedPy = candidate);
        } catch (_) { /* keep looking */ }
    }
    return null;
}

// The engine is a long-lived dependency of the bot, so probe the interpreter
// once at startup instead of on the first upload.
let primingPy = null;
function primePython() {
    if (cachedPy !== undefined) return Promise.resolve(cachedPy);
    if (!primingPy) {
        primingPy = (async () => {
            for (const c of PY_CANDIDATES) {
                if (await probeCommand(c, ['--version'], IS_PYTHON, 5000)) return c;
            }
            return null;
        })().then((found) => {
            cachedPy = found;
            primingPy = null;
            return cachedPy;
        }, (err) => {
            cachedPy = null;
            primingPy = null;
            console.error('[LuraphV14] python probe failed:', err && err.message);
            return null;
        });
    }
    return primingPy;
}

function parseVersion(src) {
    const m = VERSION_BANNER.exec(src);
    if (!m) return null;
    const parts = m[1].split('.').map(Number);
    if (parts.some((n) => !Number.isFinite(n))) return null;
    return { raw: m[1], major: parts[0], minor: parts[1] };
}

// One detector per minor the bot offers. `want` is that minor.
//
// With a version banner the file matches exactly one entry - that is the only
// reliable way to tell 14.6 from 14.7 from 14.8 from 14.9, since they differ in
// loader shape, not in anything a shell pattern pins down (14.7 and 14.8 both
// ship the VM as the whole file; 14.6, 14.7 and 14.9 all use the LZ loader).
//
// Without a banner the file has to show v14's own shape - the VM closure table
// (with the step wrapper, or shipped as the whole file) plus an LPH marker.
// Nothing weaker counts: claiming a non-Luraph file as v14 is worse than
// missing one, because the user gets a "deobfuscation" of something that was
// never obfuscated. The bot's menu still offers every version by hand.
const V14_MINORS = [6, 7, 8, 9];

function detect(content, want) {
    const src = String(content || '');
    const version = parseVersion(src);
    if (version && version.major !== 14) return { pass: false, score: 0, version };
    if (version && version.minor !== want) return { pass: false, score: 0, version };
    // the banner names the engine and the build: enough on its own
    if (version) return { pass: true, score: 10, version };
    let score = 0;
    const table = INLINE_VM.test(src) || CLOSURE_TABLE.test(src);
    if (table) score += 6;
    if (table && STEP_WRAPPER.test(src)) score += 2;
    if (LPH_MARK.test(src)) score += 4;
    return { pass: score >= 8, score, version };
}

function detectorFor(want) {
    const key = 'isLuraphV14' + String(want).replace('.', '');
    return (c) => {
        const r = detect(c, want);
        return { [key]: r.pass, score: r.score, version: r.version };
    };
}

const detectLuraphV146 = detectorFor(6);
const detectLuraphV147 = detectorFor(7);
const detectLuraphV148 = detectorFor(8);
const detectLuraphV149 = detectorFor(9);

function engineStatus() {
    if (!fs.existsSync(ENGINE_PY)) {
        return { ok: false, reason: `the v14 engine is not installed on this host (${ENGINE_PY} missing)` };
    }
    if (!fs.existsSync(LUAU_EXE) || !fs.existsSync(LUAU_AST_EXE)) {
        return { ok: false, reason: 'the v14 engine is missing its Luau runtime (deobf/bin)' };
    }
    if (!pythonCommand()) {
        return { ok: false, reason: 'Python is needed on this host to run the v14 engine' };
    }
    return { ok: true, reason: null };
}

// The engine's own summary of the run. It goes to stderr, not into the trace:
// the delivered trace is comment-free, so the banner that used to carry these
// numbers is stripped from the file (traceout.strip_comments).
function readTraceSummary(stderr) {
    const m = /\[\*\]\s*v14 trace:\s*(\d+)\s+statement\(s\),\s*(\d+)\s+chain\(s\),\s*status:\s*(.+)/.exec(String(stderr || ''));
    if (!m) return {};
    return { statements: Number(m[1]), chains: Number(m[2]), runStatus: m[3].trim() };
}

function tidyEngineOutput(text) {
    // The engine's trace starts with its own banner block; keep it, it carries
    // the status line, but make sure there is exactly one blank line after it
    // so the result reads as a normal Luau file.
    return String(text || '').replace(/\r\n/g, '\n').replace(/\n{3,}/g, '\n\n').trimEnd() + '\n';
}

async function deobfuscateLuraphV14(content, filename) {
    const started = Date.now();
    const status = engineStatus();
    if (!status.ok) {
        return { success: false, error: `The Luraph v14 engine is unavailable: ${status.reason}.` };
    }

    const stamp = Date.now() + '_' + Math.random().toString(36).slice(2, 8);
    const workDir = path.join(os.tmpdir(), `lv14_${stamp}`);
    const stem = (path.basename(String(filename || 'input.lua')) || 'input.lua').replace(/\.luau?$/i, '') || 'input';
    const inputPath = path.join(workDir, `${stem}.lua`);

    let stdout = '';
    let stderr = '';
    const python = pythonCommand();
    try {
        fs.mkdirSync(workDir, { recursive: true });
        fs.writeFileSync(inputPath, content, 'utf8');
        // --no-devirt: the v14 plugin has no lifter, its output is the trace.
        // --debug keeps the trace file in output/ instead of a temp dir that
        // is deleted before we could read it.
        const res = await runProcess(python, [
            ENGINE_PY, inputPath,
            '--obfuscator', 'luraph_v14',
            '--no-devirt',
            '--debug',
            '--timeout', String(DEFAULT_TIMEOUT),
        ], { cwd: workDir, timeout: (DEFAULT_TIMEOUT + 180) * 1000 });
        stdout = (res && res.stdout) || '';
        stderr = (res && res.stderr) || '';
    } catch (err) {
        stdout = (err && err.stdout) || stdout;
        stderr = (err && err.stderr) || String((err && err.message) || '');
    } finally {
        // the engine works in the input's own output/ folder
    }

    const tracePath = path.join(workDir, 'output', `${stem}.deobf.luau`);
    let output = '';
    try { if (fs.existsSync(tracePath)) output = fs.readFileSync(tracePath, 'utf8'); } catch (_) { output = ''; }

    try { fs.rmSync(workDir, { recursive: true, force: true }); } catch (_) {}

    if (!output.trim()) {
        const detail = String(stderr || '').trim().split('\n').filter((l) => /^\[!\]/.test(l)).join('\n');
        return {
            success: false,
            error: 'The Luraph v14 engine could not run this script to completion.'
                + (detail ? `\n\`\`\`\n${detail.slice(0, 800)}\n\`\`\`` : ''),
        };
    }

    const body = tidyEngineOutput(output);
    const info = readTraceSummary(stderr);

    // A reconstruction with nothing in it is not a deobfuscation. Handing back
    // a file that holds less than the input reads as success and sends the user
    // off to check a file that says nothing, so say what happened instead: the
    // loader ran but the payload never did.
    const codeLines = body.split('\n').filter((l) => l.trim() && !l.trim().startsWith('--')).length;
    if (codeLines === 0) {
        return {
            success: false,
            error: 'This script decrypted its loader but nothing else ran: there is no '
                + 'behaviour to reconstruct.\n'
                + 'That normally means the payload is fetched at runtime (a webhook, a '
                + 'loadstring of remote code) and the host is not reachable, or the script '
                + 'only reacts to events this environment never raises.',
        };
    }

    return {
        success: true,
        output: body,
        stats: {
            inputSize: Buffer.byteLength(content, 'utf8'),
            outputSize: Buffer.byteLength(body, 'utf8'),
            decodedStrings: [],
            // report honestly what came back: the file itself says nothing
            statements: info.statements,
            chains: info.chains,
            runStatus: info.runStatus,
        },
        detected: 'Luraph v14',
        elapsed: (Date.now() - started) / 1000,
    };
}

module.exports = {
    detectLuraphV146,
    detectLuraphV147,
    detectLuraphV148,
    detectLuraphV149,
    V14_MINORS,
    deobfuscateLuraphV14,
    engineStatus,
    primePython,
    readTraceSummary,
    DEFAULT_TIMEOUT,
};
