// -- made by jamie @_jmi. OR @jmialt_ (JOIN OMNI DBF (https://dsc.gg/odbf))
'use strict';

// Comment stripping for deobfuscator output.
//
// A naive `s.replace(/--.*$/gm, '')` corrupts output the moment a payload
// contains "--" inside a string, which for deobfuscated Lua is extremely common
// (URLs, chat text, comparison chains). So this walks the source and tracks
// string state instead.

/** Length of the long bracket that starts at `i`, or null if it is not one. */
function longBracketLevel(src, i) {
    if (src[i] !== '[') return null;
    let j = i + 1;
    let level = 0;
    while (src[j] === '=') { level++; j++; }
    return src[j] === '[' ? level : null;
}

/** Index just past the closing quote of the string starting at `i`. */
function scanQuoted(src, i) {
    const quote = src[i];
    let j = i + 1;
    while (j < src.length) {
        const c = src[j];
        if (c === '\\') { j += 2; continue; }
        if (c === quote) return j + 1;
        if (c === '\n') return j; // unterminated: stop at the newline
        j++;
    }
    return j;
}

/**
 * Removes Lua comments. Long comments (`--[[ ]]`, `--[==[ ]==]`) go entirely;
 * line comments lose their text but keep the newline so line numbers and the
 * shape of the file survive. Text inside strings and long strings is left
 * alone. A leading shebang is kept.
 */
function stripLuaComments(src) {
    if (typeof src !== 'string' || src.length === 0) return src;
    const n = src.length;
    let out = '';
    let i = 0;

    if (src.startsWith('#!')) {
        const nl = src.indexOf('\n');
        if (nl === -1) return src;
        out = src.slice(0, nl) + '\n';
        i = nl + 1;
    }

    while (i < n) {
        const c = src[i];

        if (c === '[') {
            const level = longBracketLevel(src, i);
            if (level !== null) {
                const close = ']' + '='.repeat(level) + ']';
                const end = src.indexOf(close, i);
                const stop = end === -1 ? n : end + close.length;
                out += src.slice(i, stop);
                i = stop;
                continue;
            }
        }

        if (c === '"' || c === "'") {
            const stop = scanQuoted(src, i);
            out += src.slice(i, stop);
            i = stop;
            continue;
        }

        if (c === '-' && src[i + 1] === '-') {
            const level = longBracketLevel(src, i + 2);
            if (level !== null) {
                const close = ']' + '='.repeat(level) + ']';
                const end = src.indexOf(close, i + 2);
                i = end === -1 ? n : end + close.length;
            } else {
                const nl = src.indexOf('\n', i);
                i = nl === -1 ? n : nl;
            }
            continue;
        }

        out += c;
        i++;
    }
    return out;
}

/**
 * stripLuaComments plus light tidy-up: trailing whitespace, runs of blank
 * lines, and no leading blank lines. Keeps the file readable without touching
 * indentation.
 */
function stripComments(src) {
    let text = stripLuaComments(src);
    const lines = text.split('\n').map(l => l.replace(/[ \t]+$/, ''));
    const out = [];
    let blank = false;
    for (const line of lines) {
        if (line === '') {
            if (blank) continue;
            blank = true;
        } else {
            blank = false;
        }
        out.push(line);
    }
    while (out.length && out[0] === '') out.shift();
    while (out.length && out[out.length - 1] === '') out.pop();
    return out.join('\n');
}

module.exports = { stripLuaComments, stripComments };
